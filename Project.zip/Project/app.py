from fastapi import FastAPI, File, UploadFile, WebSocket, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from ultralytics import YOLO
import requests
import torch
from PIL import Image
import io
import json
import asyncio
import os
import sqlite3
from datetime import datetime, timedelta
import time
import logging
from typing import Optional, List, Dict, Any
import shutil
import uuid
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("app.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Constants
DB_PATH = "detection_data.db"
UPLOAD_DIR = "uploads"
MODEL_PATH = "best.pt"
IMAGE_RETENTION_DAYS = 30  # Number of days to keep uploaded images
MAX_CLIENTS = 100  # Maximum number of WebSocket clients

# Email configuration
# Store these in environment variables in production
EMAIL_CONFIG = {
    "enabled": True,  # Set to False to disable email alerts
    "api_key": os.getenv("MAILGUN_API_KEY", "4a574ca1446e5a46b5af19ea3a872c8e-3af52e3b-8ade6136"),
    "domain": os.getenv("MAILGUN_DOMAIN", "sandbox16c8c49d8ba949e4a3d7137683f8eab8.mailgun.org"),
    "recipient": os.getenv("ALERT_EMAIL", "d23ce160@charusat.edu.in")
}

# Create upload directory if it doesn't exist
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Store connected WebSocket clients
websocket_clients = set()

# Store recent detections for new clients
recent_detections = {"drones": 0, "birds": 0, "detections": []}

# Load YOLO model
try:
    model = YOLO(MODEL_PATH)
    logger.info("🔍 YOLO model loaded successfully")
except Exception as e:
    logger.error(f"❌ Failed to load YOLO model: {e}")
    model = None


class DatabaseManager:
    """Database connection and operations manager"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.init_db()
        
    def get_connection(self):
        """Get a database connection with row factory"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_db(self):
        """Initialize the SQLite database with required tables"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Create detections table with separate date and time columns
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS detections (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                confidence REAL,
                x1 REAL,
                y1 REAL,
                x2 REAL,
                y2 REAL,
                date DATE NOT NULL, -- Date of detection
                time TIME NOT NULL, -- Time of detection
                image_path TEXT
            )
            ''')
            
            # Add indexes for frequent queries
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_detections_type ON detections(type)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_detections_date ON detections(date)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_detections_time ON detections(time)')
            
            # Create a summary table for quick stats access
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS detection_summary (
                date DATE PRIMARY KEY,
                birds_count INTEGER DEFAULT 0,
                drones_count INTEGER DEFAULT 0,
                last_updated DATETIME
            )
            ''')
            
            conn.commit()
            conn.close()
            logger.info("🗃️ Database initialized successfully with separate date and time columns")
            return True
        except Exception as e:
            logger.error(f"❌ Database initialization error: {e}")
            return False
    
    def add_detection(self, detection_type: str, confidence: float, 
                      bounding_box: List[float], image_path: Optional[str] = None) -> bool:
        """Add a detection to the database with separate date and time columns"""
        conn = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Validate detection type
            if detection_type not in ["bird", "drone"]:
                logger.warning(f"⚠️ Invalid detection type: {detection_type}")
                return False
                
            # Get current date and time
            current_date = datetime.now().strftime("%Y-%m-%d")
            current_time = datetime.now().strftime("%H:%M:%S")
            
            # Use parameterized queries to prevent SQL injection
            cursor.execute(
                "INSERT INTO detections (type, confidence, x1, y1, x2, y2, date, time, image_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (detection_type, confidence, bounding_box[0], bounding_box[1], bounding_box[2], bounding_box[3], current_date, current_time, image_path)
            )
            
            # Update the summary table
            if detection_type == "bird":
                cursor.execute(
                    "INSERT INTO detection_summary (date, birds_count, last_updated) VALUES (?, 1, ?) "
                    "ON CONFLICT(date) DO UPDATE SET birds_count = birds_count + 1, last_updated = ?",
                    (current_date, datetime.now(), datetime.now())
                )
            elif detection_type == "drone":
                cursor.execute(
                    "INSERT INTO detection_summary (date, drones_count, last_updated) VALUES (?, 1, ?) "
                    "ON CONFLICT(date) DO UPDATE SET drones_count = drones_count + 1, last_updated = ?",
                    (current_date, datetime.now(), datetime.now())
                )
            
            conn.commit()
            logger.info(f"✅ Added {detection_type} detection to database with date and time")
            return True
        except sqlite3.Error as e:
            logger.error(f"❌ Database error when adding detection: {e}")
            if conn:
                conn.rollback()
            return False
        finally:
            if conn:
                conn.close()
    
    def get_detections(self, limit: int = 100, type_filter: Optional[str] = None,
                      start_date: Optional[str] = None, end_date: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get detections with expanded filtering options"""
        conn = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            query = "SELECT * FROM detections WHERE 1=1"
            params = []
            
            if type_filter:
                query += " AND type = ?"
                params.append(type_filter)
                
            if start_date:
                query += " AND date >= ?"
                params.append(start_date)
                
            if end_date:
                query += " AND date <= ?"
                params.append(end_date)
                
            query += " ORDER BY date DESC, time DESC LIMIT ?"
            params.append(limit)
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Convert rows to dictionaries
            detections = []
            for row in rows:
                detections.append({
                    "id": row["id"],
                    "type": row["type"],
                    "confidence": row["confidence"],
                    "bounding_box": [row["x1"], row["y1"], row["x2"], row["y2"]],
                    "date": row["date"],
                    "time": row["time"],
                    "image_path": row["image_path"]
                })
                
            return detections
        except sqlite3.Error as e:
            logger.error(f"❌ Database error when retrieving detections: {e}")
            return []
        finally:
            if conn:
                conn.close()
    
    def get_summary(self, days: int = 7) -> Dict[str, Any]:
        """Get detection summary statistics"""
        conn = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Get the specified days of summary data
            if days == -1:  # All time
                cursor.execute(
                    "SELECT date, birds_count, drones_count FROM detection_summary ORDER BY date DESC"
                )
            else:
                cursor.execute(
                    "SELECT date, birds_count, drones_count FROM detection_summary "
                    "WHERE date >= date('now', ?) ORDER BY date DESC",
                    (f'-{days} days',)
                )
            
            rows = cursor.fetchall()
            
            # Calculate totals
            cursor.execute("SELECT SUM(birds_count) as total_birds, SUM(drones_count) as total_drones FROM detection_summary")
            totals = cursor.fetchone()
            
            summary = {
                "daily_data": [dict(row) for row in rows],
                "total_birds": totals["total_birds"] or 0,
                "total_drones": totals["total_drones"] or 0
            }
            
            return summary
        except sqlite3.Error as e:
            logger.error(f"❌ Database error when retrieving summary: {e}")
            return {"daily_data": [], "total_birds": 0, "total_drones": 0}
        finally:
            if conn:
                conn.close()
    
    def cleanup_old_records(self, days: int = 90) -> bool:
        """Clean up old detection records"""
        conn = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Get cutoff date
            cutoff_date = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
            
            # Get images to delete
            cursor.execute(
                "SELECT image_path FROM detections WHERE date < ? AND image_path IS NOT NULL",
                (cutoff_date,)
            )
            images = [row["image_path"] for row in cursor.fetchall() if row["image_path"]]
            
            # Delete old records
            cursor.execute(
                "DELETE FROM detections WHERE date < ?",
                (cutoff_date,)
            )
            
            deleted_count = cursor.rowcount
            conn.commit()
            
            logger.info(f"🧹 Cleaned up {deleted_count} old detection records")
            
            # Delete image files
            for img_path in images:
                if os.path.exists(img_path):
                    try:
                        os.remove(img_path)
                    except Exception as e:
                        logger.warning(f"⚠️ Could not delete image {img_path}: {e}")
            
            return True
        except sqlite3.Error as e:
            logger.error(f"❌ Database error during cleanup: {e}")
            if conn:
                conn.rollback()
            return False
        finally:
            if conn:
                conn.close()

# Initialize database manager
db_manager = DatabaseManager(DB_PATH)

# Function to send email alert
def send_email_alert() -> tuple:
    """Send email alert when a drone is detected"""
    if not EMAIL_CONFIG["enabled"]:
        logger.info("📧 Email alerts disabled")
        return 200, "Email alerts disabled"
        
    try:
        response = requests.post(
            f"https://api.mailgun.net/v3/{EMAIL_CONFIG['domain']}/messages",
            auth=("api", EMAIL_CONFIG["api_key"]),
            data={
                "from": f"Drone Alert <mailgun@{EMAIL_CONFIG['domain']}>",
                "to": EMAIL_CONFIG["recipient"],
                "subject": "🚨 Drone Detected!",
                "text": f"A drone has been detected at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}! Please take necessary actions."
            },
            timeout=5  # Add timeout to prevent hanging
        )
        logger.info(f"📧 Email sent with status code: {response.status_code}")
        return response.status_code, response.text
    except Exception as e:
        logger.error(f"❌ Failed to send email alert: {e}")
        return 500, str(e)

# Function to send data to all connected WebSocket clients
async def broadcast_to_clients(data: Dict[str, Any]) -> None:
    """Broadcast data to all connected WebSocket clients"""
    if not websocket_clients:
        logger.info("⚠️ No WebSocket clients connected")
        return
        
    logger.info(f"📡 Broadcasting to {len(websocket_clients)} clients")
    
    # Convert data to JSON string if it's not already
    if isinstance(data, dict):
        json_data = json.dumps(data)
    else:
        json_data = data if isinstance(data, str) else json.dumps(data)
    
    # Make a copy of the set to avoid runtime modification errors
    clients_to_remove = set()
    
    # Send to all clients
    for client in websocket_clients:
        try:
            await client.send_text(json_data)
        except Exception as e:
            logger.warning(f"⚠️ Error sending to client: {e}")
            clients_to_remove.add(client)
    
    # Remove disconnected clients
    for client in clients_to_remove:
        websocket_clients.discard(client)
    
    if clients_to_remove:
        logger.info(f"🔄 Removed {len(clients_to_remove)} disconnected clients")

# Function to clean up old image files
def cleanup_old_images() -> None:
    """Clean up old image files"""
    try:
        cutoff_date = datetime.now() - timedelta(days=IMAGE_RETENTION_DAYS)
        count = 0
        
        for filename in os.listdir(UPLOAD_DIR):
            file_path = os.path.join(UPLOAD_DIR, filename)
            if os.path.isfile(file_path):
                # Check file modification time
                file_time = datetime.fromtimestamp(os.path.getmtime(file_path))
                if file_time < cutoff_date:
                    os.remove(file_path)
                    count += 1
        
        if count > 0:
            logger.info(f"🧹 Cleaned up {count} old image files")
    except Exception as e:
        logger.error(f"❌ Error cleaning up old images: {e}")

# Background task for periodic cleanup
@app.on_event("startup")
async def startup_event():
    """Run tasks on application startup"""
    # Initial cleanup
    db_manager.cleanup_old_records()
    cleanup_old_images()

# Serve static files
@app.get("/")
async def get_index():
    """Serve the index.html file"""
    return FileResponse("index.html")

@app.get("/dashboard.html")
async def get_dashboard():
    """Serve the dashboard.html file"""
    return FileResponse("dashboard.html")

@app.post("/predict/")
async def predict(file: UploadFile = File(...)):
    """Process an uploaded image for object detection"""
    global recent_detections
    
    # Validate model
    if model is None:
        raise HTTPException(status_code=500, detail="Model not loaded")
    
    try:
        # Read and validate the image
        contents = await file.read()
        if not contents:
            raise HTTPException(status_code=400, detail="Empty file")
        
        # Generate a unique filename
        file_ext = os.path.splitext(file.filename)[1] if file.filename else ".jpg"
        unique_filename = f"{uuid.uuid4().hex}{file_ext}"
        image_path = os.path.join(UPLOAD_DIR, unique_filename)
        
        # Save the image
        image = Image.open(io.BytesIO(contents))
        image.save(image_path)
        
        # Run detection
        results = model(image)
        
        # Process results
        drone_count = 0
        bird_count = 0
        class_names = {0: "bird", 1: "drone"}
        
        detections = []
        for result in results:
            for box in result.boxes:
                class_id = int(box.cls)
                confidence = float(box.conf)
                bounding_box = box.xyxy.tolist()[0]  # Get bounding box coordinates
                
                detected_type = class_names.get(class_id, "unknown")
                if detected_type == "drone":
                    drone_count += 1
                elif detected_type == "bird":
                    bird_count += 1
                
                # Add to database
                db_manager.add_detection(detected_type, confidence, bounding_box, image_path)
                
                # Format for API response
                detection_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                detections.append({
                    "time": detection_time,
                    "type": detected_type,
                    "bounding_box": bounding_box,
                    "confidence": confidence
                })
        
        # Send email alert if drone detected
        if drone_count > 0:
            status, response = send_email_alert()
            logger.info(f"📧 Email Alert Status: {status}")
        
        # Prepare response data
        data_to_send = {
            "drones": drone_count, 
            "birds": bird_count, 
            "detections": detections,
            "timestamp": datetime.now().isoformat()
        }
        
        # Store recent detections for new clients
        recent_detections = data_to_send
        
        # Broadcast to all WebSocket clients
        await broadcast_to_clients(data_to_send)
        
        return data_to_send
        
    except Exception as e:
        logger.error(f"❌ Error in prediction: {e}")
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")

@app.get("/test-detection/")
async def test_detection():
    """Generate a test detection for testing the system"""
    # Create a test detection
    test_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    test_data = {
        "drones": 1,
        "birds": 1,
        "detections": [
            {"time": test_time, "type": "bird", "bounding_box": [10, 10, 100, 100], "confidence": 0.95},
            {"time": test_time, "type": "drone", "bounding_box": [150, 150, 250, 250], "confidence": 0.87}
        ],
        "timestamp": datetime.now().isoformat()
    }
    
    # Add test data to database
    for detection in test_data["detections"]:
        db_manager.add_detection(
            detection["type"], 
            detection["confidence"], 
            detection["bounding_box"]
        )
    
    # Update recent detections
    global recent_detections
    recent_detections = test_data
    
    # Broadcast to all clients
    await broadcast_to_clients(test_data)
    
    return {"status": "success", "detail": "Test detection sent", "data": test_data}

@app.get("/api/detections/")
async def get_api_detections(
    limit: int = 100, 
    type: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
):
    """API endpoint to fetch detection data with filtering"""
    detections = db_manager.get_detections(limit, type, start_date, end_date)
    return {"detections": detections, "count": len(detections)}

@app.get("/api/summary/")
async def get_api_summary(days: int = 7):
    """API endpoint to fetch summary statistics"""
    return db_manager.get_summary(days)

@app.get("/api/status/")
async def get_api_status():
    """API endpoint to check system status"""
    return {
        "status": "online",
        "model_loaded": model is not None,
        "websocket_clients": len(websocket_clients),
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/cleanup/")
async def trigger_cleanup(days: int = 90):
    """API endpoint to trigger manual cleanup"""
    db_result = db_manager.cleanup_old_records(days)
    cleanup_old_images()
    return {"status": "success", "database_cleanup": db_result}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time updates"""
    await websocket.accept()
    
    # Check if max clients reached
    if len(websocket_clients) >= MAX_CLIENTS:
        await websocket.send_text(json.dumps({
            "error": "Too many connections", 
            "message": "Maximum number of clients reached"
        }))
        await websocket.close(code=1008)  # Policy violation
        return
    
    # Add to clients set
    websocket_clients.add(websocket)
    logger.info(f"🟢 WebSocket Client Connected: {len(websocket_clients)} active clients")

    try:
        # Send initial confirmation message
        await websocket.send_text(json.dumps({
            "status": "connected", 
            "message": "WebSocket connection established",
            "timestamp": datetime.now().isoformat()
        }))
        
        # Send recent detections if available
        if recent_detections["detections"]:
            logger.info("📤 Sending recent detections to new client")
            await websocket.send_text(json.dumps(recent_detections))
        
        # Wait for messages
        while True:
            message = await websocket.receive_text()
            logger.info(f"📥 Received from client: {message}")
            
            # Handle client requesting historical data
            if message == "get_history":
                detections = db_manager.get_detections(50)
                summary = db_manager.get_summary()
                history_data = {
                    "detections": detections,
                    "summary": summary,
                    "timestamp": datetime.now().isoformat()
                }
                await websocket.send_text(json.dumps(history_data))
            
            # Handle ping message
            elif message == "ping":
                await websocket.send_text(json.dumps({
                    "type": "pong",
                    "timestamp": datetime.now().isoformat()
                }))
                
    except Exception as e:
        logger.warning(f"🔴 WebSocket Disconnected: {e}")
    finally:
        if websocket in websocket_clients:
            websocket_clients.remove(websocket)
        logger.info(f"🔴 WebSocket Client Disconnected: {len(websocket_clients)} clients remaining")

# Handle graceful shutdown
@app.on_event("shutdown")
def shutdown_event():
    """Run tasks on application shutdown"""
    logger.info("🛑 Application shutting down")